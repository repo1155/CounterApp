package com.example.counterapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import com.example.counterapp.ui.theme.CounterAppTheme

class MainActivity : ComponentActivity() {
    private val vm: CounterViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // ensure notification channel
        NotificationHelper.createChannelIfNeeded(this)
        // schedule default alarm on first run if not set
        val repo = CounterRepository(this)
        val (h,m) = repo.getNotificationTime()
        repo.scheduleDailyNotification(h,m)

        setContent {
            CounterAppTheme {
                AppNav(vm)
            }
        }
    }
}
