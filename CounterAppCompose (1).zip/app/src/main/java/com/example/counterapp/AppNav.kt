package com.example.counterapp

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Settings
import androidx.compose.runtime.getValue
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.rememberNavController
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.compose.material3.Icon
import androidx.navigation.compose.currentBackStackEntryAsState

@Composable
fun AppNav(vm: CounterViewModel) {
    val navController = rememberNavController()
    val items = listOf("home", "history", "settings")
    Scaffold(
        bottomBar = {
            NavigationBar {
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val current = navBackStackEntry?.destination?.route ?: "home"
                NavigationBarItem(selected = current=="home", onClick = { navController.navigate("home") { popUpTo("home") { inclusive = false } } }, icon = { Icon(Icons.Default.Home, contentDescription = null) }, label = { Text("Home") })
                NavigationBarItem(selected = current=="history", onClick = { navController.navigate("history") }, icon = { Icon(Icons.Default.History, contentDescription = null) }, label = { Text("History") })
                NavigationBarItem(selected = current=="settings", onClick = { navController.navigate("settings") }, icon = { Icon(Icons.Default.Settings, contentDescription = null) }, label = { Text("Settings") })
            }
        }
    ) { innerPadding ->
        NavHost(navController, startDestination = "home", modifier = Modifier.fillMaxSize().padding(innerPadding)) {
            composable("home") { HomeScreen(vm) }
            composable("history") { HistoryScreen(vm) }
            composable("settings") { SettingsScreen(vm) }
        }
    }
}
