package com.example.counterapp

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items

@Composable
fun HistoryScreen(vm: CounterViewModel) {
    val history by vm.history.collectAsState()
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("History", style = MaterialTheme.typography.titleLarge)
        Spacer(modifier = Modifier.height(8.dp))
        LazyColumn {
            items(history.entries.toList().sortedByDescending { it.key }) { entry ->
                ListItem(
                    headlineText = { Text(entry.key) },
                    supportingText = { Text("${entry.value} clicks") }
                )
                Divider()
            }
        }
    }
}
