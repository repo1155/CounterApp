package com.example.counterapp

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class CounterRepository(private val context: Context) {
    private val PREFS = "counter_prefs_compose"
    private val KEY = "click_history"

    private fun prefs() = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun getHistory(): Map<String, Int> {
        val json = JSONObject(prefs().getString(KEY, "{}")!!)
        val map = mutableMapOf<String, Int>()
        json.keys().forEach { map[it] = json.optInt(it, 0) }
        return map
    }

    fun addClickForToday() {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val today = sdf.format(Date())
        val json = JSONObject(prefs().getString(KEY, "{}")!!)
        val now = json.optInt(today, 0) + 1
        json.put(today, now)
        prefs().edit().putString(KEY, json.toString()).apply()
    }

    // Settings
    fun saveDailyGoal(goal: Int) {
        prefs().edit().putInt("daily_goal", goal).apply()
    }

    fun getDailyGoal(): Int {
        return prefs().getInt("daily_goal", 100)
    }

    fun saveNotificationTime(hour: Int, minute: Int) {
        prefs().edit().putInt("notif_hour", hour).apply()
        prefs().edit().putInt("notif_min", minute).apply()
    }

    fun getNotificationTime(): Pair<Int, Int> {
        val h = prefs().getInt("notif_hour", 9)
        val m = prefs().getInt("notif_min", 0)
        return Pair(h, m)
    }

    fun scheduleDailyNotification(hour: Int, minute: Int) {
        val alarmMgr = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, NotificationReceiver::class.java)
        val pending = PendingIntent.getBroadcast(context, 0, intent, PendingIntent.FLAG_IMMUTABLE)

        // Cancel previous alarm
        alarmMgr.cancel(pending)

        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            if (before(Calendar.getInstance())) add(Calendar.DATE, 1)
        }

        alarmMgr.setInexactRepeating(AlarmManager.RTC_WAKEUP, calendar.timeInMillis, AlarmManager.INTERVAL_DAY, pending)
        saveNotificationTime(hour, minute)
    }

    fun markSummaryNotifiedForToday() {
        val key = "notified_" + SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        prefs().edit().putBoolean(key, true).apply()
    }

    fun wasSummaryNotifiedToday(): Boolean {
        val key = "notified_" + SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        return prefs().getBoolean(key, false)
    }
}
