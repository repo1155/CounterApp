package com.example.counterapp

import android.app.TimePickerDialog
import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.util.*

@Composable
fun SettingsScreen(vm: CounterViewModel) {
    val ctx = LocalContext.current
    val repo = CounterRepository(ctx)
    var goal by remember { mutableStateOf(repo.getDailyGoal()) }
    val (hour0, min0) = repo.getNotificationTime()
    var hour by remember { mutableStateOf(hour0) }
    var minute by remember { mutableStateOf(min0) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Settings", style = MaterialTheme.typography.titleLarge)
        Spacer(modifier = Modifier.height(12.dp))
        OutlinedTextField(value = goal.toString(), onValueChange = { goal = it.toIntOrNull() ?: goal }, label = { Text("Daily Goal") })
        Spacer(modifier = Modifier.height(12.dp))
        Button(onClick = {
            val cal = Calendar.getInstance()
            TimePickerDialog(ctx, { _, h, m ->
                hour = h; minute = m
            }, hour, minute, true).show()
        }) {
            Text("Pick Notification Time: ${'$'}{hour.toString().padStart(2,'0')}:${'$'}{minute.toString().padStart(2,'0')}")
        }
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = {
            repo.saveDailyGoal(goal)
            repo.scheduleDailyNotification(hour, minute)
        }) {
            Text("Save Settings")
        }
    }
}
